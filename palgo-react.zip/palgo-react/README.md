# Palgo Landing Page — React + Vite + React Router

## Project Structure
```
palgo-react/
├── index.html               ← Vite entry (root level)
├── vite.config.js
├── package.json
├── src/
│   ├── main.jsx             ← React entry point
│   ├── App.jsx              ← Routes + ThemeContext
│   ├── styles.css           ← Global CSS variables
│   ├── components/
│   │   ├── Navbar.jsx
│   │   ├── Footer.jsx
│   │   └── LegalLayout.jsx
│   └── pages/
│       ├── Home.jsx
│       ├── PrivacyPolicy.jsx
│       ├── TermsOfService.jsx
│       └── CookiePolicy.jsx
```

## How to run (PowerShell / Windows)

```powershell
# 1. Delete old node_modules if they exist
Remove-Item -Recurse -Force node_modules

# 2. Install
npm install

# 3. Start dev server
npm start
```

Then open http://localhost:5173 in your browser.

## Build for production
```powershell
npm run build
```
Upload the `dist/` folder to Netlify or Vercel.
